import React, { useEffect, useRef, useState } from 'react';
import { getEngine, useEngineTick } from './store';
import type { Engine } from './sim/engine';
import { faDateTime, faTime, faPercent, faOrderState, faShipmentState, faMoney } from './sim/labels';
import CustomerView from './ui/CustomerView';
import OpsView from './ui/OpsView';
import SystemView from './ui/SystemView';

type Perspective = 'customer' | 'ops' | 'system';

export default function App() {
  const e: Engine = getEngine();
  useEngineTick(400);
  const [persp, setPersp] = useState<Perspective>('customer');
  const [focusOrder, setFocusOrder] = useState<string | null>(null);
  const [navOpen, setNavOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [speed, setSpeed] = useState(1);
  const speedRef = useRef(speed);
  speedRef.current = speed;

  const st = e.state;

  // clock loop: advance sim while running
  useEffect(() => {
    const id = setInterval(() => {
      if (e.running) e.tick(400 * speedRef.current);
    }, 400);
    return () => clearInterval(id);
  }, []);

  const unread = st.notifications.filter(n => !n.read).length;
  const markAllRead = () => {
    st.notifications.forEach(n => { n.read = true; });
    e.notify();
  };
  const onMyOrder = (id: string) => { setFocusOrder(id); setPersp('ops'); };

  const PerspectiveIcon = ({ p }: { p: Perspective }) => (persp === p ? <span className="ic on-ic">✓</span> : <span className="ic">•</span>);

  return (
    <div className="app">
      <header className="hdr">
        <button className="hamburger" onClick={() => setNavOpen(v => !v)}>☰</button>
        <div className="logo">پلتفرم بازارگاه و زنجیره تأمین <span className="lt">شبیه‌ساز تعاملی</span></div>
        <div className="persp">
          {([['customer', 'مشتری'], ['ops', 'عملیات'], ['system', 'سیستم']] as const).map(([k, t]) => (
            <button key={k} className={`pbtn ${persp === k ? 'on' : ''}`} onClick={() => setPersp(k as Perspective)}>
              {t}
            </button>
          ))}
        </div>
        <div className="spacer" />
        <div className="statusbar hide-m">
          <span className="live-dot" />
          <span className="sb-l">زمان شبیه‌سازی</span>
          <b className="num">{faDateTime(st.simTime)}</b>
        </div>
        <div className="statusbar hide-m">
          <span className="sb-l">سرعت</span>
          <span className="num">{speed.toLocaleString('fa-IR')}×</span>
        </div>
        <div className="statusbar hide-m">
          <span className="sb-l">کل موجودی</span>
          <span className="num">{Object.values(st.inv).flatMap(w => Object.values(w)).flatMap(c => Object.values(c)).reduce((a, b) => a + b, 0).toLocaleString('fa-IR')}</span>
        </div>
        <div className="notif" onClick={() => { setNotifOpen(v => !v); if (!notifOpen && unread) markAllRead(); }}>
          🔔{unread > 0 && <span className="badge">{unread.toLocaleString('fa-IR')}</span>}
        </div>
      </header>

      <nav className={`side ${navOpen ? 'open' : ''}`}>
        <div className="sp">پرسپکتیو</div>
        {([['customer', 'مشتری — فروشگاه'], ['ops', 'عملیات — مرکز فرمان'], ['system', 'سیستم — جریان فرایند']] as const).map(([k, t]) => (
          <button key={k} className={`navi ${persp === k ? 'on' : ''}`} onClick={() => { setPersp(k as Perspective); setNavOpen(false); }}>
            <PerspectiveIcon p={k as Perspective} /> {t}
          </button>
        ))}
        <div className="sp">کنترل زمان</div>
        <div className="clock">
          <button className="btn primary" onClick={() => { e.running = true; e.autoOrdersEnabled = st.forces.autoOrders; e.notify(); }}>▶ شروع</button>
          <button className="btn" onClick={() => { e.running = false; e.notify(); }}>⏸ توقف</button>
          <button className="btn" onClick={() => { e.stepOnce(); }}>⏭ مرحله بعد</button>
          <button className="btn" onClick={() => { e.running = false; setSpeed(4); e.speedMult = 4; setTimeout(() => { e.running = true; e.notify(); }, 0); }}>⏩ اجرای سریع</button>
          <button className="btn" onClick={() => { setSpeed(8); e.speedMult = 8; e.runAll(); }}>⏭ اجرای کامل</button>
          <button className="btn danger" onClick={() => { if (confirm('همه وضعیت‌ها بازنشانی شود؟')) { e.applyScenario(st.scenarioId); e.notify(); } }}>↺ بازنشانی</button>
        </div>
        <div className="pad-x tiny">
          سرعت فعلی: <b className="num">{speed.toLocaleString('fa-IR')}×</b> — وضعیت: {e.running ? 'در حال اجرا' : 'متوقف'}
        </div>
        <div className="sp">راهنما</div>
        <div className="tiny pad-x muted">
          سه پرسپکتیو یک state مشترک را می‌بینند. هیچ داده‌ای جعلی نیست؛ سناریوها قطعی‌اند و بازنشانی کامل،
          سیستم را به ابتدا برمی‌گرداند.
        </div>
      </nav>

      <main className="main">
        {persp === 'customer' && (
          <CustomerView e={e} onOpenOrder={onMyOrder} focusOrderId={null} clearFocus={() => { }} toast={(m, t) => e.notifyCustomer('اعلان', m, t === 'bad' ? 'SYSTEM' : 'ORDER')} />
        )}
        {persp === 'ops' && <OpsView e={e} focusOrderId={focusOrder} clearFocus={() => setFocusOrder(null)} />}
        {persp === 'system' && <SystemView e={e} />}
      </main>

      <footer className="ftr">
        مدل شبیه‌سازی تعاملی؛ بازیگر دیده‌شده: <b>مشتری</b>
        {' | '}مدل: بازارگاه/OMS/WMS/لجستیک معکوس
        {' | '}مرجع: مستند عمومی، استاندارد صنعت و مدل‌سازی شبیه‌سازی‌شده — نه افشا و نه داده‌های داخلی هیچ شرکتی.
        {' '}<span className="badge-src pub">مستند عمومی</span> <span className="badge-src ind">استاندارد صنعت</span> <span className="badge-src sim">شبیه‌سازی</span>
      </footer>

      {notifOpen && <NotifPanel e={e} onClose={() => setNotifOpen(false)} />}
    </div>
  );
}

function NotifPanel({ e, onClose }: { e: Engine; onClose: () => void }) {
  const st = e.state;
  return (
    <div className="notif-panel" onClick={ev => ev.stopPropagation()}>
      <div className="head">
        <b>اعلان‌ها</b>
        <span className="tiny">({st.notifications.length.toLocaleString('fa-IR')} مورد)</span>
        <div className="spacer" />
        <button className="btn sm" onClick={onClose}>✕</button>
      </div>
      <div className="list">
        {st.notifications.length === 0 ? <div className="pad-x tiny">اعلانی وجود ندارد.</div> : st.notifications.slice().reverse().map(n => (
          <div key={n.id} className="row">
            <span className={`ic ${n.read ? 'read' : ''}`}>{n.read ? '○' : '●'}</span>
            <div>
              <b>{n.titleFa}</b>
              <div className="tiny">{n.bodyFa}</div>
              <div className="tiny muted mono">{n.orderId ?? ''} {faTime(n.at)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
